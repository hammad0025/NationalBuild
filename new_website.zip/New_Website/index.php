<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
    <link rel="icon" href="images//NFI_smallicon.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" />
    <link rel="stylesheet" href="css/style.css">
    <title>Natural Food Innovations</title>
</head>

<body data-spy='scroll' data-target='#main-nav'>
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-md navbar-light py-4 navbar-custom" id='main-nav'>
        <div class="container">
            <a href="#" class="navbar-brand">
                <img src="images/NFI_logo.png" width='225' height='100' alt="">
            </a>
            <button class='navbar-toggler' data-toggle='collapse' data-target='#navbarCollapse'>
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="#learn" class="nav-link">Learn</a>
                    </li>
                    <li class="nav-item">
                        <a href="#about" class="nav-link">About</a>
                    </li>
                    <li class="nav-item">
                        <a href="#gallery" class="nav-link">Our Food</a>
                    </li>
                    <li class="nav-item">
                        <a href="#contact" class="nav-link">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <section class="main-header" class='py-5'>
            <div class="header-overlay text-center text-white">
                <div class="display-2 header-content header-content-title">Natural Food <br>Innovations</div>
                <!-- <p class="header-content header-paragraph">Explore our many culinary creations</p> -->
            </div>
    </section>

    <!-- Feature -->
    <section id="learn">
        <div class="container py-3">
            <div class="row">
                <div class="col">
                        <h1 class="text-center py-5">Organic. Natural. Real.</h1>
                </div>
            </div>
            <div class="row text-center pb-5">
                <div class="col-md-4">
                    <div class="mb-2"><i class="d-inline fas fa-check fa-2x"></i></div>
                    <h2>Solutions</h2>
                    <p>Creating simple solutions to complex problems</p>
                </div>
                <div class="col-md-4">
                        <div class="mb-2"><i class="d-inline fas fa-seedling fa-2x"></i></div>
                    <h2>Products</h2>
                    <p>Line extension formulations and assistance with the commercialization process</p>
                </div>
                <div class="col-md-4">
                        <div class="mb-2"><i class="d-inline fas fa-chart-line fa-2x"></i></div>
                    <h2>Consulting</h2>
                    <p>Independent consulting company specializing in consumer recipe development</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Information -->
    <section class="information text-white py-2" id="about">
        <div class="py-5">
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <h1 class="py-3 information-header">Why Natural Food Innovations?</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col py-2">
                        <p>Natural Food Innovations is an independent consulting company specializing in product development. From concept to commercialization, we begin formulations with 
industrial ingredients, keeping the the commercial process front and foremost. Your end product should be scalable, not impossible.
Samantha brings over 30 years of culinary experience, spanning two continents, and with her extensive knowledge of the commercialization process, is able to bring your product to life.</p><br>
                        <p>"<i>Samantha Apter is a highly skilled and innovative product developer.  Not only did she solve our difficult shelf life issues, she made our products taste better than ever.  Plus, she is a joy to work with. I highly recommend her."</i> <br> --Nancy Kalish, founder & CEO, Rule Breaker Snacks</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

     <!-- Gallery -->
     <section class="py-5 text-center gallery" id="gallery">
        <div class="container">
            <h1>Natural Food</h1>
            <p>Some of our products</p>
            <div class="gallery-row row mb-4">
                <div class="col-sm-4">
                    <a href="images/PB_Choc_Chip_Stack copy.jpg" data-toggle="lightbox">
                        <img src="/images/PB_Choc_Chip_Stack copy.jpg" class="img-fluid">
                    </a>
                </div>
                <div class="col-sm-4">
                    <a href="images/Brownie unpackaged-no shadow 1.18.jpg" data-toggle="lightbox">
                        <img src="images/Brownie unpackaged-no shadow 1.18.jpg" class="img-fluid">
                    </a>
                </div>
                <div class="col-sm-4">
                    <a href="images/Brownie 3-stack 1.18.jpg" data-toggle="lightbox">
                        <img src="images/Brownie 3-stack 1.18.jpg" class="img-fluid">
                    </a>
                </div>
            </div>
            <div class="gallery-row row mb-4">
                    <div class="col-sm-4">
                        <a href="images/Both Caddies Open 1.18.jpg" data-toggle="lightbox">
                            <img src="images/Both Caddies Open 1.18.jpg" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a href="images/BirthdayCake_Stack copy.jpg" data-toggle="lightbox">
                            <img src="images/BirthdayCake_Stack copy.jpg" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a href="images/Brownie w:Bite 1.18.jpg" data-toggle="lightbox">
                            <img src="images/Brownie w:Bite 1.18.jpg" class="img-fluid">
                        </a>
                    </div>
            </div>
        </div>
     </section>

     

     <!-- Contact -->
     <section id="contact" class="contact-form">
            <div class="container py-3">
                    <div class="row">
                        <div class="col-md-8 mx-auto">
                               <div class="display-4 py-3 text-center text-white">Contact Us</div>
                            <form method="post" id="contactusForm">
                               <div class='form-group'>
                                       <label for="name">Name</label>
                                       <input class='form-control' name="name" id="name" />
                               </div>
                               <div class='form-group'>
                                       <label for="email">Email</label>
                                       <input class='form-control' id="email" name="email" />
                               </div>
                               <div class='form-group'>
                                       <label for="message">Message</label>
                                       <textarea class='form-control' id="message" name="message" rows="3"></textarea>
                               </div>
                               <div class='form-group'>
<div id="error" style="color: red;"></div><div id="success" style="color: white;"></div>
                               </div>


                               <input type="button" id="Submit" name="Submit" value="Submit" class="btn btn-secondary mb-4">
                            </form>
                        </div>
                        <!-- <div class="d-none d-md-block col-md-4 form-column">
                            <div class="form-side">
                                <div class="form-overlay"></div>
                            </div>
                        </div> -->
                        <div class="logo col-md-4 form-column text-center align-self-center p-2">
                                 <img src="images/vegnews.png" class="img-fluid">
                        </div>
                    </div>
                </div>
     </section>
    <!-- Footer -->
    <footer class="py-5 custom-footer">
            <div class="container d-flex flex-column flex-sm-row justify-content-sm-between align-items-center">
                   <div class="footer-brand">Natural Food Innovations &copy; <span id="year"></span></div>
                   <div class="d-flex flex-sm-row social-links">
                        <div><a href="https://www.facebook.com/Natural-Food-Innovations-2032020063496070/?modal=admin_todo_tour" target="_blank"><i class="fab fa-facebook"></i></a></div>
                        <div class="ml-5"><a href="https://www.instagram.com/naturalfoodinnovations/" target="_blank"><i class="fab fa-instagram"></i></a></div>
                        
                   </div>
            </div>
    </footer> 



    <script
        src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script> <!-- can't use slim with scroll spy -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script> 
    <script>
        //footer date
        $('#year').text(new Date().getFullYear());

          //Lightbox Init (from http://ashleydw.github.io/lightbox/)
        $(document).on('click', '[data-toggle="lightbox"]', function(event) {
            console.log('clicked');
            event.preventDefault();
            $(this).ekkoLightbox();
        });

               //init scrollspy
       $('body').scrollspy({
            target: '#main-nav'
        });

        //smooth scrolling
        $('#main-nav a').on('click', function(event) {
            if (this.hash !== '') {
                event.preventDefault();

                const hash = this.hash;

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    window.location.hash = hash;
                });
            }
        });

        $("#Submit").click(function(){
        $('#error').html('');
        $('#success').html('');
         var nameRegex = /^[a-zA-Z ]{2,30}$/;
            if (! nameRegex.test($('#name').val())) {
                $('#error').html('Please enter valid name');
                return true;
            }
        var emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (! emailRegex.test($('#email').val().toLowerCase())) {
                $('#error').html('Please enter valid email id');
                return true;
            }
            if ($('#message').val().trim() == '') {
                $('#error').html('Please enter message');
                return true;
            }
        $.ajax({
           url: 'contactusmailer.php',
           data: {
              name: $('#name').val(),
              email: $('#email').val(),
              message: $('#message').val()
           },
           error: function(err) {
        debugger;
              $('#error').html('<p>Something went wrong. Please try again.</p>');
           },
           success: function(data) {
        debugger;
              $('#success').html('<p>Thank you for showing interest. We will get back to you soon.</p>');
              $('#name').val('')
              $('#email').val('');
              $('#message').val('');
           },
           type: 'POST'
        });

     });
    </script>

</body>
</html>