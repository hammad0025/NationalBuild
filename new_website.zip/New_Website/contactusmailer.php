<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$name= $_REQUEST['name'];
$email = $_REQUEST['email'];
$from='apter0327@gmail.com';
$message= $_REQUEST['message'];
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

$subject = 'Enquiry - Contact US';
$message_body = '<strong>Name: </strong>'.$name.' <br/><strong>Email ID: </strong> '.$email.' <br/><strong>Message: </strong>'.$message;
$headers .= 'From: '.$from.' '. "\r\n";
mail('samantha@naturalfoodinnovations.com',$subject,$message_body,$headers);
echo 'Success';
}
?>